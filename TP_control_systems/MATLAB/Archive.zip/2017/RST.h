//
//  controller.h
//  
//
//  Created by EPFL on 25.05.21.
//

#ifndef controller_h
#define controller_h

int initialize(char *);
void calc(double [], double []);

#endif /* controller_h */
