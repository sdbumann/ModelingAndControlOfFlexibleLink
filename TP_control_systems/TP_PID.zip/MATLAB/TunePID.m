clear;
load('Qube','G'); % Load model 

% Your PID tuning code here
Kp = 0.0183;
Ki = 0.0371;
Kd = 0.0013;
Tf = 0.0112;
Ts = 0.001;
PID = pid(Kp,Ki,Kd,Tf,Ts)

CL = feedback(G*PID,1);
step(CL,(0:2500)*Ts)
shg


% At the end, save data to binary file
u_max = 15; % max voltage
FormatPID(Kp,Ki,Kd,Tf,Ts,u_max); % save data to .bin

