// Philippe Schuchert
// SCI-STI-AK
// philippe.schuchert@epfl.ch
// July 2021
/* --------------------------- */

/*
  
 LabVIEW caches shared objects that are loaded. To avoid restarting LabVIEW everytime we want to reload the shared object, make a shared object that loads other shared objects. This (cached) shared object, also implements a more accurate wait until next function.
 
 */

#include <dlfcn.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>

#include "CtrlLibLoader.h"

struct timespec ts;
struct timespec ts1;

bool isLoaded = false;



void *ctrlLibHandle;
int (*initFunction)(char[]);
double (*calcFunction)(double);


int init(char pathLib[], char pathInit[])
{
    
    if (isLoaded) {closeLib();} // close previous lib 
    
    ctrlLibHandle = dlopen(pathLib, RTLD_NOW); // open new lib
    
    if (ctrlLibHandle) {
        // success
        *(void**)(&initFunction) = dlsym(ctrlLibHandle, "initialize");
        *(void**)(&calcFunction) = dlsym(ctrlLibHandle, "calc");
        
        int loadingError = initFunction(pathInit);
        if (loadingError < 0)
        {
            closeLib();
            return -1;
            
        }
        isLoaded = true;
        }
    else
    {
        perror("Library could not be opened");
        return -1;
    }
    
    return 0;
}

double calc(double error)
{
    return calcFunction(error);
}


void closeLib()
{
    dlclose(ctrlLibHandle);
    isLoaded = false;
}


long waitUntilNext(long Ts)
{
    // Ts the wait time in ms
    if (Ts)
    {
    timespec_get(&ts, TIME_UTC);
    unsigned long TsNanoS = Ts*1000*1000;
    unsigned long time_ns = TsNanoS - (ts.tv_nsec%TsNanoS);
    
    while (1) {
        //   spin lock
        timespec_get(&ts1, TIME_UTC);
        if ((ts1.tv_nsec-ts.tv_nsec) % (4*TsNanoS)> time_ns)
        {
            break;
        }
        else{
            usleep(20);
        }
    }
    }
    return (Ts) ? (ts1.tv_sec*1000*1000 + ts1.tv_nsec/1000) : -1;
}
