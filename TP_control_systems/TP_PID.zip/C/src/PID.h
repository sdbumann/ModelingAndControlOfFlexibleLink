#ifndef PID_h
#define PID_h

int initialize(char *);
void calc(double [], double []);

#endif /* PID_h */
